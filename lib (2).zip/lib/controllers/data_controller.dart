import 'package:firebase_database/firebase_database.dart';
import 'package:admin_app/models/med_model.dart';
import 'package:admin_app/models/trans_model.dart';
import 'package:intl/intl.dart'; // Import this for date formatting

class DataController {
  final DatabaseReference _gudangRef =
      FirebaseDatabase.instance.ref('gudangData');
  final DatabaseReference _transaksiRef =
      FirebaseDatabase.instance.ref('transaksiData');
  final DatabaseReference _logRef =
      FirebaseDatabase.instance.ref().child('gudangLog');

  // Fetch Gudang data from Firebase
// Fetch Gudang data from Firebase
Future<Map<String, Gudang>> getGudangData() async {
  try {
    final snapshot = await _gudangRef.get();
    print('Raw snapshot data: ${snapshot.value}');

    if (snapshot.exists) {
      final data = snapshot.value as Map<dynamic, dynamic>? ?? {};
      return data.map((key, value) {
        if (value is Map<dynamic, dynamic>) {
          return MapEntry(
            key as String,
            Gudang.fromJson(value as Map<String, dynamic>, key as String),
          );
        } else {
          print('Unexpected data format for Gudang: $value');
          return MapEntry(
            key as String,
            Gudang(
              id: key as String,
              name: '',
              tipe: '',
              totalObat: 0,
              expiryDetails: {},
            ),
          );
        }
      }).cast<String, Gudang>();
    } else {
      return {};
    }
  } catch (e) {
    print('Error fetching Gudang data: $e');
    return {};
  }
}







  // Fetch Transaksi data from Firebase
  Future<Map<String, Transaksi>> getTransaksiData() async {
    try {
      final snapshot = await _transaksiRef.get();
      print('Raw snapshot data: ${snapshot.value}');

      if (snapshot.exists) {
        final Map<dynamic, dynamic>? data =
            snapshot.value as Map<dynamic, dynamic>?;
        print('Data runtime type: ${data.runtimeType}');
        print('Data content: $data');

        if (data == null) {
          return {};
        }

        return data.map((key, value) {
          if (value is Map<dynamic, dynamic>) {
            final Map<String, dynamic> convertedValue =
                Map<String, dynamic>.from(value);
            return MapEntry(
              key as String,
              Transaksi.fromJson(convertedValue),
            );
          } else {
            print('Unexpected data format for Transaksi: $value');
            return MapEntry(
                key as String,
                Transaksi(
                  id: key as String,
                  date: '',
                  gudangId: '',
                  name: '',
                  tipe: '',
                  totalTrans: 0,
                ));
          }
        }).cast<String, Transaksi>();
      } else {
        return {};
      }
    } catch (e) {
      print('Error fetching Transaksi data: $e');
      return {};
    }
  }

  // Add a new Gudang entry to Firebase
  Future<void> addGudang(String id, Gudang gudang) async {
    try {
      await _gudangRef.child(id).set(gudang.toJson());
    } catch (e) {
      print('Error adding Gudang data: $e');
    }
  }

  // Add a new Transaksi entry to Firebase
  Future<void> addTransaksi(String id, Transaksi transaksi) async {
    try {
      await _transaksiRef.child(id).set(transaksi.toJson());
    } catch (e) {
      print('Error adding Transaksi data: $e');
    }
  }

  // Update an existing Gudang entry in Firebasea
  Future<void> deleteExpiryItem(String gudangId, String expiryDate) async {
    try {
      // Fetch current Gudang data
      final gudangData = await getGudangData();
      if (!gudangData.containsKey(gudangId)) {
        print('Gudang ID not found: $gudangId');
        return;
      }

      Gudang gudang = gudangData[gudangId]!;

      // Check if expiry details contain the specified expiryDate
      if (!gudang.expiryDetails.values
          .any((detail) => detail.expiryDate == expiryDate)) {
        print('Expiry date not found: $expiryDate');
        return;
      }

      // Remove the expiry detail from the Gudang's expiryDetails
      gudang.expiryDetails
          .removeWhere((key, detail) => detail.expiryDate == expiryDate);

      // Update total quantity
      int newTotalQuantity = gudang.expiryDetails.values
          .fold(0, (sum, detail) => sum + detail.quantity);

      Gudang updatedGudang = Gudang(
        id: gudang.id,
        name: gudang.name,
        tipe: gudang.tipe,
        totalObat: newTotalQuantity,
        expiryDetails: gudang.expiryDetails,
      );

      print('Updating Gudang stock: ${updatedGudang.toJson()}');

      // Update the Gudang data in Firebase
      await updateGudang(gudang.id, updatedGudang);

      // Optionally, you can also log the deletion in gudangLog
      await _logRef.push().set({
        'action': 'delete',
        'expiryDetail': {
          'name': gudang.name,
          'expiryDate': expiryDate,
          'quantity': 0, // Log quantity if needed
        },
        'timestamp': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      print('Error deleting Expiry Item: $e');
    }
  }

  ///
  Future<void> updateGudang(String id, Gudang gudang) async {
    try {
      await _gudangRef.child(id).update(gudang.toJson());
    } catch (e) {
      print('Error updating Gudang data: $e');
    }
  }

  ///////// Update Gudang stock based on transaction
  Future<void> updateGudangStock(String gudangId, int quantityChange) async {
    try {
      // Fetch current Gudang data
      final gudangData = await getGudangData();
      if (!gudangData.containsKey(gudangId)) {
        print('Gudang ID not found: $gudangId');
        return;
      }

      Gudang gudang = gudangData[gudangId]!;

      // Check if the new total stock will be negative
      int newTotalQuantity = gudang.totalObat + quantityChange;
      if (newTotalQuantity < 0) {
        print('Insufficient stock in Gudang');
        return;
      }

      // Prioritize expiry details based on submission date
     List<ExpiryDetail> expiryList = gudang.expiryDetails.values.toList();
expiryList.sort((a, b) => a.submissionDate.compareTo(b.submissionDate));

int remainingQuantity = quantityChange;
Map<String, ExpiryDetail> updatedExpiryDetails = {};

for (var expiry in expiryList) {
  if (remainingQuantity <= 0) break;

  if (expiry.quantity <= remainingQuantity) {
    remainingQuantity -= expiry.quantity;
  } else {
    updatedExpiryDetails[expiry.id] = ExpiryDetail(
      id: expiry.id,
      expiryDate: expiry.expiryDate,
      quantity: expiry.quantity - remainingQuantity,
      submissionDate: expiry.submissionDate,
    );
    remainingQuantity = 0;
  }
}


      // Create updated Gudang object
      Gudang updatedGudang = Gudang(
        id: gudang.id,
        name: gudang.name,
        tipe: gudang.tipe,
        totalObat: newTotalQuantity,
        expiryDetails: updatedExpiryDetails,
      );

      print('Updating Gudang stock: ${updatedGudang.toJson()}');

      // Update the Gudang data in Firebase
      await updateGudang(gudang.id, updatedGudang);
    } catch (e) {
      print('Error updating Gudang stock: $e');
    }
  }

//////////////
  Future<int> getMonthlyTotalTransactions(String month) async {
    try {
      final snapshot = await _transaksiRef.get();
      if (snapshot.exists) {
        final Map<dynamic, dynamic>? data =
            snapshot.value as Map<dynamic, dynamic>?;
        if (data != null) {
          int total = 0;
          data.forEach((key, value) {
            if (value is Map<dynamic, dynamic>) {
              final transaction =
                  Transaksi.fromJson(Map<String, dynamic>.from(value));
              final dateParts = transaction.date.split('/');
              if (dateParts.length == 3) {
                final transactionMonth =
                    '${dateParts[2]}-${dateParts[1]}'; // "YYYY-MM"
                if (transactionMonth == month) {
                  // Convert totalTrans to positive if it is negative
                  total += transaction.totalTrans
                      .abs(); // Use abs() to get absolute value
                }
              }
            }
          });
          return total;
        }
      }
      return 0;
    } catch (e) {
      print('Error fetching monthly total transactions: $e');
      return 0;
    }
  }

  Future<int> getMonthlyAddedGudang(String month) async {
    try {
      final snapshot = await _gudangRef.get(); // Get the top-level Gudang data
      if (snapshot.exists) {
        final Map<dynamic, dynamic>? data =
            snapshot.value as Map<dynamic, dynamic>?;
        if (data != null) {
          int total = 0;
          final DateFormat inputDateFormat =
              DateFormat('dd/MM/yyyy'); // Define the date format

          data.forEach((key, value) {
            if (value is Map<dynamic, dynamic>) {
              final gudang = Map<String, dynamic>.from(value);
              final expiryDetails =
                  gudang['expiryDetails'] as Map<dynamic, dynamic>?;

              if (expiryDetails != null) {
                expiryDetails.forEach((expiryKey, expiryValue) {
                  if (expiryValue is Map<dynamic, dynamic>) {
                    final expiryDetail = Map<String, dynamic>.from(expiryValue);

                    // Log the expiry detail for debugging
                    print('Expiry Detail: $expiryDetail');

                    final submissionDateStr =
                        expiryDetail['submissionDate'] as String?;
                    final quantity = expiryDetail['quantity'] as num?;

                    if (submissionDateStr != null && quantity != null) {
                      try {
                        final DateTime submissionDate =
                            inputDateFormat.parse(submissionDateStr);
                        final String submissionMonth =
                            '${submissionDate.year}-${submissionDate.month.toString().padLeft(2, '0')}';

                        // Log the extracted month for debugging
                        print('Extracted Submission Month: $submissionMonth');
                        print('Comparing with: $month');

                        // Compare submissionMonth with the input month
                        if (submissionMonth == month) {
                          total += quantity.toInt();
                        }
                      } catch (e) {
                        print(
                            'Error parsing submission date: $submissionDateStr');
                      }
                    } else {
                      print('Invalid expiry detail: $expiryDetail');
                    }
                  }
                });
              }
            }
          });
          print('Total Added Gudang for $month: $total'); // Log the final total
          return total;
        }
      }
      return 0;
    } catch (e) {
      print('Error fetching monthly added Gudang total: $e');
      return 0;
    }
  }

  //////////for exp itulah
  Future<int> getMonthlyAddedGudangForMedicine(String medicineName) async {
  try {
    final snapshot = await _logRef.get(); // Ensure _logRef points to gudangLog
    final data = snapshot.value as Map<dynamic, dynamic>?;

    if (data == null) {
      print('No data found in gudangLog.');
      return 0;
    }

    int totalAddedGudang = 0;
    final now = DateTime.now();
    final firstDayOfMonth = DateTime(now.year, now.month, 1);
    final lastDayOfMonth = DateTime(now.year, now.month + 1, 0); // Last day of the current month

    print('First Day of Month: $firstDayOfMonth');
    print('Last Day of Month: $lastDayOfMonth');

    Map<String, num> lastQuantities = {}; // Track the last quantity for each medicine

    data.forEach((key, value) {
      if (value is Map<dynamic, dynamic>) {
        final action = value['action'] as String?;
        final after = value['after'] as Map<dynamic, dynamic>?;
        final timestampStr = value['timestamp'] as String?;
        final timestamp = DateTime.tryParse(timestampStr ?? '');

        print(
            'Processing entry with action: $action, timestamp: $timestampStr');

        if (action == 'update' && after != null) {
          final afterName = after['name'] as String?;
          final totalObat = after['totalObat'] as num?;

          if (afterName == medicineName && totalObat != null) {
            final lastQuantity = lastQuantities[medicineName] ?? 0;
            if (timestamp != null &&
                timestamp.isAfter(firstDayOfMonth.subtract(Duration(days: 1))) &&
                timestamp.isBefore(lastDayOfMonth.add(Duration(days: 1)))) {
              final change = totalObat.toInt() - lastQuantity.toInt();
              if (change > 0) {
                totalAddedGudang += change;
                print('Added $change to totalAddedGudang.');
              }
              lastQuantities[medicineName] = totalObat;
            }
          }
        }
      }
    });

    print(
        'Total Added Gudang for $medicineName in the current month: $totalAddedGudang');
    return totalAddedGudang;
  } catch (e) {
    print("Error fetching monthly added Gudang: $e");
    return 0;
  }
}

/////
Future<int> getMonthlyDeletedGudangForMedicine(String medicineName) async {
  try {
    final snapshot = await _logRef.get(); // Ensure _logRef points to gudangLog
    final data = snapshot.value as Map<dynamic, dynamic>?;

    if (data == null) {
      print('No data found in gudangLog.');
      return 0;
    }

    int totalDeletedGudang = 0;
    final now = DateTime.now();
    final firstDayOfMonth = DateTime(now.year, now.month, 1);
    final lastDayOfMonth = DateTime(now.year, now.month + 1, 0); // Last day of the current month

    print('First Day of Month: $firstDayOfMonth');
    print('Last Day of Month: $lastDayOfMonth');

    for (var entry in data.entries) {
      final action = entry.value['action'] as String?;
      final timestampStr = entry.value['timestamp'] as String?;
      final timestamp = DateTime.tryParse(timestampStr ?? '');

      print('Processing entry with action: $action, timestamp: $timestampStr');

      if (action == 'delete_expiry_detail') {
        final gudangId = entry.value['gudangId'] as String?;
        final deletedDetail = entry.value['deletedDetail'] as Map<dynamic, dynamic>?;

        if (deletedDetail != null && gudangId != null) {
          final quantity = deletedDetail['quantity'] as num?;

          print('Fetched deleted detail: gudangId: $gudangId, quantity: $quantity');

          // Fetch Gudang details by gudangId
          final gudangSnapshot = await _gudangRef.child(gudangId).get();
          final gudangData = gudangSnapshot.value as Map<dynamic, dynamic>?;

          if (gudangData != null) {
            final name = gudangData['name'] as String?;
            if (name == medicineName && quantity != null) {
              if (timestamp != null &&
                  timestamp.isAfter(firstDayOfMonth.subtract(Duration(days: 1))) &&
                  timestamp.isBefore(lastDayOfMonth.add(Duration(days: 1)))) {
                totalDeletedGudang += quantity.toInt();
                print('Added $quantity to totalDeletedGudang.');
              } else {
                print('Timestamp $timestamp is out of range.');
              }
            } else {
              print('Medicine name does not match or quantity is null.');
            }
          } else {
            print('No data found for Gudang ID: $gudangId.');
          }
        } else {
          print('No deleted detail or gudangId found in log entry.');
        }
      } else {
        print('Action is not delete_expiry_detail.');
      }
    }

    print('Total Deleted Gudang for $medicineName in the current month: $totalDeletedGudang');
    return totalDeletedGudang;
  } catch (e) {
    print("Error fetching monthly deleted Gudang: $e");
    return 0;
  }
}





}

import 'package:flutter/material.dart';
import 'package:admin_app/views/admin_page.dart'; // Import the AdminPage

class AppDrawer extends StatelessWidget {
  final VoidCallback onLogout;

  AppDrawer({required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            // decoration: BoxDecoration(
            //   color: Colors.blue,
            // ),
            child: Text(
              'Menu',
              style: TextStyle(
                // color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          // Add this ListTile for Admin Page
          ListTile(
            leading: Icon(Icons.admin_panel_settings),
            title: Text('Admin Page'),
            onTap: () {
              Navigator.pop(context); // Close the drawer
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminPage()),
              );
            },
          ),
          // Logout button
          ListTile(
            leading: Icon(Icons.logout),
            title: Text('Logout'),
            onTap: () {
              Navigator.pop(context); // Close the drawer
              onLogout(); // Trigger the logout function
            },
          ),
        ],
      ),
    );
  }
}

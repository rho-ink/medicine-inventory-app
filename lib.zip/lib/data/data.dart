// Map<String, dynamic> transaksiData = {
//   'transaksiData': {
//     'trans1': {
//       'tipe': 'Obat',
//       'name': 'Lanzoprazole',
//       'totalTrans': -12,
//       'date': '16/07/2024',
//       'gudangId': 'gud1', // Reference to gudangData
//     },
//     'trans2': {
//       'tipe': 'UPTD',
//       'name': 'Kasa',
//       'totalTrans': -5,
//       'date': '15/07/2024',
//       'gudangId': 'gud2', // Reference to gudangData
//     },
//   },
// };

// Map<String, dynamic> gudangData = {
//   'gudangData': {
//     'gud1': {
//       'tipe': 'Obat',
//       'name': 'Lanzoprazole',
//       'totalObat': 120,
//       'expiryDetails': {
//         'detail1': {
//           'submissionDate': '11/07/2024',
//           'expiryDate': '11/12/2023',
//           'quantity': 50,
//         },
//         'detail2': {
//           'submissionDate': '11/07/2024',
//           'expiryDate': '11/12/2024',
//           'quantity': 70,
//         },
//       },
//     },
//     'gud2': {
//       'tipe': 'UPTD',
//       'name': 'Kasa',
//       'totalObat': 100,
//       'expiryDetails': {
//         'detail1': {
//           'submissionDate': '01/01/2024',
//           'expiryDate': '15/06/2024',
//           'quantity': 100,
//         },
//       },
//     },
//     'gud3': {
//       'tipe': 'UPTD',
//       'name': 'Stet',
//       'totalObat': 100,
//       'expiryDetails': {
//         'detail1': {
//           'submissionDate': '01/01/2024',
//           'expiryDate': '15/06/2024',
//           'quantity': 100,
//         },
//       },
//     },
//     'gud4': {
//       'tipe': 'Obat',
//       'name': 'ACEYLCYSTEIN Capsul 200 Mg',
//       'totalObat': 0,
//       'expiryDetails': {
//         'detail1': {
//           'submissionDate': '01/01/2024',
//           'expiryDate': '15/06/2024',
//           'quantity': 100,
//         },
//       },
//     },
//   },
// };

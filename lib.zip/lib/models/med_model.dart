class Gudang {
  String id;
  String name;
  String tipe;
  int totalObat;
  Map<String, ExpiryDetail> expiryDetails;

  Gudang({
    required this.id,
    required this.name,
    required this.tipe,
    required this.totalObat,
    required this.expiryDetails,
  });

  factory Gudang.fromJson(Map<dynamic, dynamic> json, String id) {
    return Gudang(
      id: id,
      name: json['name'] as String? ?? '',
      tipe: json['tipe'] as String? ?? '',
      totalObat: json['totalObat'] as int? ?? 0,
      expiryDetails: (json['expiryDetails'] as Map<dynamic, dynamic>?)?.map(
            (k, v) => MapEntry(
              k as String,
              ExpiryDetail.fromJson(v as Map<dynamic, dynamic>),
            ),
          ) ??
          {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'tipe': tipe,
      'totalObat': totalObat,
      'expiryDetails': expiryDetails.map((k, v) => MapEntry(k, v.toJson())),
    };
  }
}

class ExpiryDetail {
  String expiryDate;
  int quantity;
  String submissionDate;

  ExpiryDetail({
    required this.expiryDate,
    required this.quantity,
    required this.submissionDate,
  });

  factory ExpiryDetail.fromJson(Map<dynamic, dynamic> json) {
    return ExpiryDetail(
      expiryDate: json['expiryDate'] as String? ?? '',
      quantity: json['quantity'] as int? ?? 0,
      submissionDate: json['submissionDate'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'expiryDate': expiryDate,
      'quantity': quantity,
      'submissionDate': submissionDate,
    };
  }
}
